<?php
	define('DB_HOST', 'localhost');
    define('DB_USER', 'jatinder');
    define('DB_PASSWORD', 'mypassword');
    define('DB_DATABASE', 'mydatabase');
?>